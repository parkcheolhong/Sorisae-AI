# 오케스트레이터-자가진단-실험-즉시-실행-원본-대상-경로-C-Use-9b762c4b90 사용 가이드

- npm install
- npm run build
- npm run start
