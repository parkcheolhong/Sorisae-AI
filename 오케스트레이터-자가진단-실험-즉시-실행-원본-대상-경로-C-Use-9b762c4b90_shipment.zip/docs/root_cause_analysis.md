# 오케스트레이터-자가진단-실험-즉시-실행-원본-대상-경로-C-Use-9b762c4b90 root cause analysis

## root causes
- semantic gate failed
- shipping zip reproduction validation failed
- test coverage too small: 0
- commerce backend implementation too small: 0
- runtime scenario marker missing: catalog flow
- runtime scenario marker missing: marketplace publish payload
- thin implementation files detected: scripts/check.sh

## enforcement
- generation failure must return failed response immediately
- shipment archive must include execution method, validation result, and failure reason files
