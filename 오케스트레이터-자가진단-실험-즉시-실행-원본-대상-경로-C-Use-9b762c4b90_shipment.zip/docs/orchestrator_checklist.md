# 오케스트레이터-자가진단-실험-즉시-실행-원본-대상-경로-C-Use-9b762c4b90 orchestrator checklist

- mode: review
- validation_profile: nextjs_app
- anchor_path: README.md
- written_files: 48
- semantic_audit_score: 82
- semantic_audit_ok: False

## Required verification

- [x] app/main.py generated
- [x] app/routes.py generated
- [x] app/services/__init__.py generated
- [x] app/services/runtime_service.py generated
- [x] docs/file_manifest.md generated
- [x] docs/output_audit.json generated
- [x] traceability_map.json generated
- [x] docs/id_registry.schema.json generated
- [x] docs/id_registry.json generated
- [x] docs/product_identity.json generated
