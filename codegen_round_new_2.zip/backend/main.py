# FILE-ID: FILE-BACKEND-MAIN-PY
# SECTION-ID: SECTION-BACKEND-MAIN-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-MAIN-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-MAIN-PY-001

import uvicorn

__all__ = ['create_application']

def create_application() -> dict:
    return {'status': 'ok'}

if __name__ == '__main__':
    uvicorn.run('app.main:app', host='0.0.0.0', port=8000)
