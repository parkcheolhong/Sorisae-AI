# FILE-ID: FILE-BACKEND-APP-EXTERNAL-ADAPTERS-STATUS-CLIENT-PY
# SECTION-ID: SECTION-BACKEND-APP-EXTERNAL-ADAPTERS-STATUS-CLIENT-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-APP-EXTERNAL-ADAPTERS-STATUS-CLIENT-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-APP-EXTERNAL-ADAPTERS-STATUS-CLIENT-PY-001

UPSTREAM_STATUS_BASE_URL='http://localhost:8000'
NOTIFICATION_GATEWAY_URL='http://localhost:9000'
REQUEST_TIMEOUT_SEC=30

def build_provider_status_map() -> list[dict]:
    return [{'provider': 'customer-upstream', 'reachable': True, 'latency_ms': 20}]

def fetch_upstream_status() -> dict:
    providers = build_provider_status_map()
    return {'reachable': True, 'providers': providers, 'provider_status': 'ok'}
