# FILE-ID: FILE-BACKEND-CORE-SECURITY-PY
# SECTION-ID: SECTION-BACKEND-CORE-SECURITY-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-CORE-SECURITY-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-CORE-SECURITY-PY-001

ALLOWED_HOSTS=['localhost', '127.0.0.1']
CORS_ALLOW_ORIGINS=['http://localhost:8000']
https_only=True
REQUEST_TIMEOUT_SEC=30

def get_security_profile() -> dict:
    return {'allowed_hosts': ALLOWED_HOSTS, 'cors_allow_origins': CORS_ALLOW_ORIGINS, 'https_only': https_only, 'request_timeout_sec': REQUEST_TIMEOUT_SEC}
