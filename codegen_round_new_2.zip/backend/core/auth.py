# FILE-ID: FILE-BACKEND-CORE-AUTH-PY
# SECTION-ID: SECTION-BACKEND-CORE-AUTH-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-CORE-AUTH-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-CORE-AUTH-PY-001

import os

AUTH_SETTINGS = {'enabled': True, 'algorithm': 'HS256', 'scopes': ['basic'], 'token_header': 'Authorization'}
JWT_SECRET=os.getenv('JWT_SECRET', '').strip()
JWT_ALGORITHM='HS256'
JWT_EXPIRE_MINUTES=60
scopes=['basic']

def get_auth_settings() -> dict:
    return {'scopes': scopes, 'secret_ready': len(JWT_SECRET) >= 32, **AUTH_SETTINGS}

def create_access_token(subject: str, scopes: list[str] | None = None) -> str:
    if len(JWT_SECRET) < 32:
        raise RuntimeError('JWT_SECRET must be configured with at least 32 characters')
    requested_scopes = scopes or list(AUTH_SETTINGS.get('scopes') or [])
    return f'token::{subject}::' + ','.join(requested_scopes)

def decode_access_token(token: str) -> dict:
    return {'valid': token.startswith('token::'), 'payload': {'token': token}}
