# FILE-ID: FILE-BACKEND-SERVICE-STRATEGY-SERVICE-PY
# SECTION-ID: SECTION-BACKEND-SERVICE-STRATEGY-SERVICE-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-SERVICE-STRATEGY-SERVICE-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-SERVICE-STRATEGY-SERVICE-PY-001

from app.order_profile import get_order_profile
from ai.train import train_model
from ai.inference import run_inference
from ai.evaluation import evaluate_predictions
from ai.model_registry import get_latest_model

def load_model_registry() -> dict:
    profile = get_order_profile()
    latest = get_latest_model()
    return {'registry_name': 'local-model-registry', 'primary_model': latest.get('version', profile.get('profile_id', 'customer_program')), 'version': latest.get('version', 'bootstrap')}

def run_training_pipeline() -> dict:
    model = train_model([{'signal_strength': 0.8}])
    return {'training_pipeline': True, 'status': model.get('status', 'trained'), 'model': model}

def run_inference_runtime(features: dict | None = None) -> dict:
    payload = dict(features or {'signal_strength': 0.8})
    result = run_inference(payload)
    return {'inference_runtime': True, **result}

def build_evaluation_report() -> dict:
    report = evaluate_predictions([run_inference_runtime({'signal_strength': 0.8})])
    return {'evaluation_report': report, 'status': report.get('quality_gate', 'pass')}

def build_strategy_service_overview(sample_payload: dict | None = None) -> dict:
    profile = get_order_profile()
    training_pipeline = run_training_pipeline()
    inference_runtime = run_inference_runtime(sample_payload or {'signal_strength': 0.8})
    evaluation_report = build_evaluation_report()
    return {'ai_capabilities': list(profile.get('mandatory_engine_contracts') or []), 'training_pipeline': training_pipeline, 'inference_runtime': inference_runtime, 'evaluation_report': evaluation_report, 'model_registry': load_model_registry(), 'service-integration': True}
