# FILE-ID: FILE-BACKEND-API-ROUTER-PY
# SECTION-ID: SECTION-BACKEND-API-ROUTER-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-API-ROUTER-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-API-ROUTER-PY-001

from backend.service.strategy_service import build_strategy_service_overview

def get_router_snapshot() -> dict:
    return {'trace_lookup': True}

def get_ai_runtime_snapshot(features: dict | None = None) -> dict:
    strategy_service = build_strategy_service_overview(features or {'signal_strength': 0.8})
    return {'model_registry': strategy_service.get('model_registry') or {}, 'training_pipeline': strategy_service.get('training_pipeline') or {}, 'inference_runtime': strategy_service.get('inference_runtime') or {}, 'evaluation_report': strategy_service.get('evaluation_report') or {}}
