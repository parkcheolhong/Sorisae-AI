/* FILE-ID: FILE-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX */
/* SECTION-ID: SECTION-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-MAIN */
/* FEATURE-ID: FEATURE-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-RUNTIME */
/* CHUNK-ID: CHUNK-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-001 */

export function OrderSummary({ items = [] }: { items?: string[] }) { return <section>{items.map((item) => <span key={item}>{item}</span>)}</section>; }
