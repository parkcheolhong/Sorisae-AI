/* FILE-ID: FILE-FRONTEND-LIB-API-CLIENT-TS */
/* SECTION-ID: SECTION-FRONTEND-LIB-API-CLIENT-TS-MAIN */
/* FEATURE-ID: FEATURE-FRONTEND-LIB-API-CLIENT-TS-RUNTIME */
/* CHUNK-ID: CHUNK-FRONTEND-LIB-API-CLIENT-TS-001 */

const baseUrl = 'http://localhost:8000';
export async function getRuntime() { try { const response = await fetch(`${baseUrl}/runtime`); if (!response.ok) { throw new Error('runtime fetch failed'); } return await response.json(); } catch (error) { throw new Error('runtime fetch failed'); } }
