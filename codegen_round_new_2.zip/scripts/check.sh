# FILE-ID: FILE-SCRIPTS-CHECK-SH
# SECTION-ID: SECTION-SCRIPTS-CHECK-SH-MAIN
# FEATURE-ID: FEATURE-SCRIPTS-CHECK-SH-RUNTIME
# CHUNK-ID: CHUNK-SCRIPTS-CHECK-SH-001

#!/usr/bin/env bash
set -euo pipefail
python -m pip install -r requirements.delivery.lock.txt
python -m compileall app backend tests
python -m pytest -q -s
