# FILE-ID: FILE-AI-ADAPTERS-PY
# SECTION-ID: SECTION-AI-ADAPTERS-PY-MAIN
# FEATURE-ID: FEATURE-AI-ADAPTERS-PY-RUNTIME
# CHUNK-ID: CHUNK-AI-ADAPTERS-PY-001

def resolve_adapter() -> dict:
    return {'decision_key': 'score', 'default_decision': 'REVIEW', 'model_endpoint': 'local://python-fastapi-ai'}
