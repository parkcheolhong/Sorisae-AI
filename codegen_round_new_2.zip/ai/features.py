# FILE-ID: FILE-AI-FEATURES-PY
# SECTION-ID: SECTION-AI-FEATURES-PY-MAIN
# FEATURE-ID: FEATURE-AI-FEATURES-PY-RUNTIME
# CHUNK-ID: CHUNK-AI-FEATURES-PY-001

def build_feature_set(payload: dict | None = None) -> dict:
    active_payload = dict(payload or {})
    return {'raw': active_payload, 'feature_count': len(active_payload), 'engine-core': True, 'feature-pipeline': True}
