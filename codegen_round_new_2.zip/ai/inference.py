# FILE-ID: FILE-AI-INFERENCE-PY
# SECTION-ID: SECTION-AI-INFERENCE-PY-MAIN
# FEATURE-ID: FEATURE-AI-INFERENCE-PY-RUNTIME
# CHUNK-ID: CHUNK-AI-INFERENCE-PY-001

from ai.model_registry import get_latest_model

def run_inference(payload: dict) -> dict:
    score = float(payload.get('signal_strength', 0.8) or 0.8)
    return {'model_version': get_latest_model().get('version', 'bootstrap'), 'score': score, 'decision': 'REVIEW', 'candidate_sets': [{'target': 'score', 'rank': 1, 'score': score}], 'prediction_runs': 1}
