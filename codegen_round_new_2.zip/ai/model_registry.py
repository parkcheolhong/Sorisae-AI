# FILE-ID: FILE-AI-MODEL-REGISTRY-PY
# SECTION-ID: SECTION-AI-MODEL-REGISTRY-PY-MAIN
# FEATURE-ID: FEATURE-AI-MODEL-REGISTRY-PY-RUNTIME
# CHUNK-ID: CHUNK-AI-MODEL-REGISTRY-PY-001

MODEL_REGISTRY = [{'version': 'bootstrap'}]

def get_latest_model() -> dict:
    return dict(MODEL_REGISTRY[-1])

def register_model_version(model: dict) -> None:
    MODEL_REGISTRY.append(dict(model))
