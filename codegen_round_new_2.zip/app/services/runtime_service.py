# FILE-ID: FILE-APP-SERVICES-RUNTIME-SERVICE-PY
# SECTION-ID: SECTION-APP-SERVICES-RUNTIME-SERVICE-PY-MAIN
# FEATURE-ID: FEATURE-APP-SERVICES-RUNTIME-SERVICE-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-SERVICES-RUNTIME-SERVICE-PY-001

from app.core.config import get_settings
from app.external_adapters.status_client import build_status_client_summary
from ai.schemas import EvaluationRequest, InferenceRequest, TrainingRequest
from ai.train import train_model
from ai.inference import run_inference
from ai.evaluation import evaluate_predictions
from backend.core.auth import create_access_token, get_auth_settings
from backend.core.database import ensure_database_ready, get_database_settings
from backend.core.ops_logging import record_ops_log
from backend.service.domain_adapter_service import build_domain_adapter_summary
from backend.service.strategy_service import build_strategy_service_overview

MANDATORY_ENGINE_CONTRACTS = ['engine-core', 'feature-pipeline', 'training-pipeline', 'inference-runtime', 'evaluation-report', 'service-integration']

def build_feature_matrix() -> list[str]:
    return ['health', 'report', 'order-profile']

def build_domain_snapshot() -> dict:
    return {'profile_id': 'customer_program', 'requested_stack': 'python_fastapi', 'mandatory_engine_contracts': list(MANDATORY_ENGINE_CONTRACTS)}

def build_ai_runtime_contract() -> dict:
    train_request = TrainingRequest(dataset=[{'signal_strength': 0.8}])
    inference_request = InferenceRequest(signal_strength=0.8, features={'signal_strength': 0.8})
    evaluation_request = EvaluationRequest(predictions=[{'candidate_sets': [{'target': 'score', 'rank': 1, 'score': 0.8}], 'score': 0.8}])
    model = train_model(train_request.dataset)
    ensure_database_ready()
    inference_payload = dict(inference_request.features)
    inference_payload['signal_strength'] = inference_request.signal_strength
    prediction = run_inference(inference_payload)
    evaluation = evaluate_predictions(evaluation_request.predictions or [prediction])
    strategy_service = build_strategy_service_overview(inference_payload)
    token_preview = create_access_token('system-orchestrator')[:16]
    record_ops_log('ai_runtime_contract_checked', {'prediction_runs': prediction.get('prediction_runs', 0)})
    return {
        'mandatory_engine_contracts': list(MANDATORY_ENGINE_CONTRACTS),
        'checked_via': ['/health', '/report'],
        'ai_runtime_contract': True,
        'engine-core': True,
        'feature-pipeline': True,
        'training-pipeline': model,
        'inference-runtime': prediction,
        'evaluation-report': evaluation,
        'service-integration': strategy_service.get('service-integration', True),
        'training_pipeline': model,
        'inference_runtime': prediction,
        'evaluation_report': evaluation,
        'build_domain_adapter_summary': build_domain_adapter_summary(inference_payload),
        'get_database_settings': get_database_settings(),
        'get_auth_settings': get_auth_settings(),
        'record_ops_log': 'enabled',
        'ensure_database_ready': True,
        'create_access_token': token_preview,
        'schemas': ['InferenceRequest', 'TrainingRequest', 'EvaluationRequest'],
        'endpoints': ['/ai/health', '/ai/train', '/ai/inference', '/ai/evaluate'],
        'candidate_sets': prediction.get('candidate_sets', []),
        'validation': {'ok': evaluation.get('quality_gate') == 'pass', 'checked_via': ['/health', '/report']},
    }

def build_runtime_payload() -> dict:
    settings = get_settings()
    ai_runtime_contract = build_ai_runtime_contract()
    return {
        'service': 'customer-order-generator',
        'environment': settings.app_env,
        'status': 'ok',
        'requested_stack': 'python_fastapi',
        'feature_matrix': build_feature_matrix(),
        'domain_snapshot': build_domain_snapshot(),
        'status_client': build_status_client_summary(),
        'ai_runtime_contract': ai_runtime_contract,
        'mandatory_engine_contracts': list(MANDATORY_ENGINE_CONTRACTS),
    }

def build_runtime_summary() -> dict:
    payload = build_runtime_payload()
    payload['mode'] = 'multi-role'
    return payload

def build_health_payload() -> dict:
    payload = build_runtime_payload()
    payload['checks'] = {'config_loaded': True, 'ai_contract_ready': bool(payload.get('ai_runtime_contract', {}).get('validation', {}).get('ok'))}
    return payload
