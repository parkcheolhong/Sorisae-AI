# FILE-ID: FILE-APP-API-ROUTES-HEALTH-PY
# SECTION-ID: SECTION-APP-API-ROUTES-HEALTH-PY-MAIN
# FEATURE-ID: FEATURE-APP-API-ROUTES-HEALTH-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-API-ROUTES-HEALTH-PY-001

from fastapi import APIRouter

from app.services.runtime_service import build_health_payload

router = APIRouter(tags=['health'])

@router.get('/health')
def health() -> dict:
    return build_health_payload()
