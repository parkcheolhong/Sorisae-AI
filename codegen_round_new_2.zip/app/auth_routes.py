# FILE-ID: FILE-APP-AUTH-ROUTES-PY
# SECTION-ID: SECTION-APP-AUTH-ROUTES-PY-MAIN
# FEATURE-ID: FEATURE-APP-AUTH-ROUTES-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-AUTH-ROUTES-PY-001

from fastapi import APIRouter, HTTPException
from backend.core.auth import create_access_token, decode_access_token, get_auth_settings

auth_router = APIRouter(prefix='/auth', tags=['auth'])

@auth_router.get('/settings')
def settings() -> dict:
    return get_auth_settings()

@auth_router.post('/token')
def token(payload: dict | None = None) -> dict:
    request_payload = payload or {}
    subject = str(request_payload.get('subject') or 'demo-user')
    scopes = list(request_payload.get('scopes') or get_auth_settings().get('scopes') or [])
    return {'access_token': create_access_token(subject, scopes=scopes), 'token_type': 'bearer', 'scopes': scopes}

@auth_router.post('/validate')
def validate(payload: dict | None = None) -> dict:
    token_value = str((payload or {}).get('token') or '').strip()
    if not token_value:
        raise HTTPException(status_code=400, detail='token is required')
    return decode_access_token(token_value)
