# FILE-ID: FILE-APP-ORDER-PROFILE-PY
# SECTION-ID: SECTION-APP-ORDER-PROFILE-PY-MAIN
# FEATURE-ID: FEATURE-APP-ORDER-PROFILE-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-ORDER-PROFILE-PY-001

ORDER_PROFILE = {'profile_id': 'customer_program', 'flow_steps': ['FLOW-001-1'], 'mandatory_engine_contracts': ['engine-core', 'feature-pipeline', 'training-pipeline', 'inference-runtime', 'evaluation-report', 'service-integration'], 'ai_enabled': True}

def get_order_profile() -> dict:
    return ORDER_PROFILE

def list_flow_steps() -> list[str]:
    return list(ORDER_PROFILE['flow_steps'])
