# FILE-ID: FILE-APP-OPS-ROUTES-PY
# SECTION-ID: SECTION-APP-OPS-ROUTES-PY-MAIN
# FEATURE-ID: FEATURE-APP-OPS-ROUTES-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-OPS-ROUTES-PY-001

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse
from backend.core.database import get_database_settings
from backend.core.ops_logging import list_ops_logs, record_ops_log
from backend.app.external_adapters.status_client import fetch_upstream_status

ops_router = APIRouter(prefix='/ops', tags=['ops'])

@ops_router.get('/logs')
def ops_logs() -> dict:
    return {'items': list_ops_logs(), 'count': len(list_ops_logs())}

@ops_router.get('/status')
def status() -> dict:
    provider = fetch_upstream_status()
    record_ops_log('ops_status_checked', {'reachable': provider.get('reachable')})
    return {'status': 'ok' if provider.get('reachable') else 'degraded', 'provider_status': provider}

@ops_router.get('/health')
def health() -> dict:
    provider = fetch_upstream_status()
    record_ops_log('ops_health_checked', {'reachable': provider.get('reachable')})
    return {'status': 'ok', 'database': get_database_settings(), 'provider_status': provider}

@ops_router.get('/metrics', response_class=PlainTextResponse)
def metrics() -> str:
    payload = list_ops_logs()
    return '\n'.join(['# HELP codeai_ops_events_total Count of ops events', '# TYPE codeai_ops_events_total counter', f'codeai_ops_events_total {len(payload)}']) + '\n'
