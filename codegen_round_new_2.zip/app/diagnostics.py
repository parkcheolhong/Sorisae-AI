# FILE-ID: FILE-APP-DIAGNOSTICS-PY
# SECTION-ID: SECTION-APP-DIAGNOSTICS-PY-MAIN
# FEATURE-ID: FEATURE-APP-DIAGNOSTICS-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-DIAGNOSTICS-PY-001

from app.services import build_runtime_payload

def list_diagnostic_checks() -> list[str]:
    return ['runtime', 'report', 'ai-runtime-contract-ready', 'ai-health-report-validated']

def validate_runtime_payload(payload: dict) -> bool:
    return bool(payload)

def build_diagnostic_report() -> dict:
    payload = build_runtime_payload()
    return {'status': 'ok', 'checks': list_diagnostic_checks(), 'ai_validation': payload.get('ai_runtime_contract', {}).get('validation', {'ok': False})}
