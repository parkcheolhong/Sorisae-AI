# FILE-ID: FILE-APP-MAIN-PY
# SECTION-ID: SECTION-APP-MAIN-PY-MAIN
# FEATURE-ID: FEATURE-APP-MAIN-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-MAIN-PY-001

from fastapi import FastAPI

from ai.router import router as ai_router
from app.api.routes.health import router as health_router
from app.auth_routes import auth_router
from app.ops_routes import ops_router
router = health_router
from app.agents.orchestrator_roles import build_orchestrator_role_matrix
from app.core.config import get_settings
from app.core.security import build_security_headers
from app.runtime import build_runtime_payload

def create_application() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.app_name, version='0.1.0')
    app.include_router(router)
    app.include_router(health_router)
    app.include_router(auth_router)
    app.include_router(ops_router)
    app.include_router(ai_router)
    app.include_router(router)

    @app.get('/')
    def root() -> dict:
        payload = build_runtime_payload()
        payload['roles'] = build_orchestrator_role_matrix()
        payload['security'] = build_security_headers()
        return payload

    @app.get('/runtime')
    def runtime() -> dict:
        return build_runtime_payload()

    @app.get('/report')
    def report() -> dict:
        payload = build_runtime_payload()
        payload['report'] = 'ok'
        return payload

    @app.get('/order-profile')
    def order_profile() -> dict:
        return {'profile_id': 'customer_program', 'mandatory_engine_contracts': []}

    return app

app = create_application()
