# FILE-ID: FILE-APP-ROUTES-PY
# SECTION-ID: SECTION-APP-ROUTES-PY-MAIN
# FEATURE-ID: FEATURE-APP-ROUTES-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-ROUTES-PY-001

from fastapi import APIRouter

router = APIRouter()

@router.get('/health')
def health() -> dict:
    return {'status': 'ok'}

@router.get('/order-profile')
def order_profile() -> dict:
    return {'profile_id': 'customer_program'}

@router.get('/report')
def report() -> dict:
    return {'report': 'ok'}

def list_routes() -> dict:
    return {'runtime': {'status': 'ok'}}
