# FILE-ID: FILE-APP-CORE-SECURITY-PY
# SECTION-ID: SECTION-APP-CORE-SECURITY-PY-MAIN
# FEATURE-ID: FEATURE-APP-CORE-SECURITY-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-CORE-SECURITY-PY-001

from app.core.config import get_settings

ALLOWED_HOSTS = ['localhost', '127.0.0.1']
CORS_ALLOW_ORIGINS = ['http://localhost:8000']
REQUEST_TIMEOUT_SEC = 30

def build_security_headers() -> dict:
    settings = get_settings()
    return {
        'has_secret_key': bool(settings.app_secret_key),
        'frame_options': 'DENY',
        'content_type_options': 'nosniff',
        'https_only': settings.app_env == 'production',
        'allowed_hosts': ALLOWED_HOSTS,
        'cors_allow_origins': CORS_ALLOW_ORIGINS,
        'request_timeout_sec': REQUEST_TIMEOUT_SEC,
    }
