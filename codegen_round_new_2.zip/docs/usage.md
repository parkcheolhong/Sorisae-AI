# 사용 가이드

사용 가이드: container run 전에 .env를 확인하고 /health와 /report를 검증합니다.
