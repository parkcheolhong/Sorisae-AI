# Runtime

requested_stack: python_fastapi
backend/core compatibility markers와 app/services runtime contract를 설명합니다.
ops health flow, auth settings flow, ai runtime contract markers를 포함합니다.
