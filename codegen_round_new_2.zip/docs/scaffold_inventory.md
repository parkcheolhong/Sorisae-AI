# Scaffold Inventory

backend/main.py
frontend/app/page.tsx
This shipment is product-ready, not scaffold-only.
