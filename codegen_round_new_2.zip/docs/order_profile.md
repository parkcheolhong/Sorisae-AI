# Order Profile

profile_id: customer_program
mandatory_engine_contracts: [engine-core, feature-pipeline, training-pipeline, inference-runtime, evaluation-report, service-integration]
marketplace publish shipment profile and engine contract markers.
