# Testing

pytest -q 실행, compileall, shipping zip 재현 검증 절차를 설명합니다.
