# Orchestrator Checklist

- [ ] dependency install verified
- [ ] standalone boot verified
- [ ] core API smoke verified
- [ ] pytest verified
- [ ] zip repro verified
