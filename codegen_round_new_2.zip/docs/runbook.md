# Runbook

JWT_SECRET, runtime diagnostics, restart flow, shipping package 운영 절차.
/auth/settings 와 /ops/health 를 포함한 ops health flow를 확인합니다.
