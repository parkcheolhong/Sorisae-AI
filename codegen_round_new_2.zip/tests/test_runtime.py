# FILE-ID: FILE-TESTS-TEST-RUNTIME-PY
# SECTION-ID: SECTION-TESTS-TEST-RUNTIME-PY-MAIN
# FEATURE-ID: FEATURE-TESTS-TEST-RUNTIME-PY-RUNTIME
# CHUNK-ID: CHUNK-TESTS-TEST-RUNTIME-PY-001

from app.services import build_runtime_payload

def test_runtime_snapshot() -> None:
    payload = build_runtime_payload()
    assert payload['service'] == 'customer-order-generator'
    assert payload['status'] == 'ok'
    assert 'ai_runtime_contract' in payload
    assert payload['ai_runtime_contract']['validation']['ok'] is True
