# FILE-ID: FILE-TESTS-TEST-ROUTES-PY
# SECTION-ID: SECTION-TESTS-TEST-ROUTES-PY-MAIN
# FEATURE-ID: FEATURE-TESTS-TEST-ROUTES-PY-RUNTIME
# CHUNK-ID: CHUNK-TESTS-TEST-ROUTES-PY-001

from fastapi.testclient import TestClient

from app.main import app
from backend.api.router import get_ai_runtime_snapshot

client = TestClient(app)

def test_ai_fastapi_endpoints() -> None:
    assert client.get('/order-profile').status_code == 200
    assert client.get('/report').status_code == 200
    assert client.get('/auth/settings').status_code == 200
    assert client.get('/ops/health').status_code == 200
    assert client.get('/ai/health').status_code == 200
    infer = client.post('/ai/inference', json={'signal_strength': 0.8, 'features': {'signal_strength': 0.8}})
    assert infer.status_code == 200
    evaluate = client.post('/ai/evaluate', json={'predictions': [{'candidate_sets': [{'target': 'score', 'rank': 1, 'score': 0.8}], 'score': 0.8}]})
    assert evaluate.status_code == 200

def test_ai_runtime_snapshot_marker() -> None:
    payload = get_ai_runtime_snapshot({'signal_strength': 0.8})
    assert payload['model_registry']
    assert payload['training_pipeline']
    assert payload['inference_runtime']
    assert payload['evaluation_report']
