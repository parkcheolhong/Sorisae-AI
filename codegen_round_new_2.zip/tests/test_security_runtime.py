# FILE-ID: FILE-TESTS-TEST-SECURITY-RUNTIME-PY
# SECTION-ID: SECTION-TESTS-TEST-SECURITY-RUNTIME-PY-MAIN
# FEATURE-ID: FEATURE-TESTS-TEST-SECURITY-RUNTIME-PY-RUNTIME
# CHUNK-ID: CHUNK-TESTS-TEST-SECURITY-RUNTIME-PY-001

from app.core.security import build_security_headers

def test_security_runtime_headers() -> None:
    payload = build_security_headers()
    assert 'request_timeout_sec' in payload
