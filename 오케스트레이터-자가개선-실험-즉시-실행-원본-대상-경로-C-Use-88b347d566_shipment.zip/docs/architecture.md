# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 architecture

- order_profile: 업무 자동화/에이전트 서비스
- summary: 작업 큐, 실행 기록, 스케줄, 경고를 포함하는 주문형 프로그램
- entities: jobs, runs, alerts, artifacts, ai_features, model_versions, inference_runs, evaluation_reports
- secure runtime boundaries: auth / ops / external status / verification
