# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 file manifest

- task: 오케스트레이터 자가개선 실험 즉시 실행

원본 대상 경로: C:\Users\WORK\source\repos\parkcheolhong\codeAI
실험 복제본 경로: C:\Users\WORK\source\repos\parkcheolhong\codeAI\uploads\tmp\codeai_admin_runtime\admin_self_experiments\codeAI_20260423_025814
실행 모드: full

[반드시 지킬 원칙]
- 1. 대상 폴더 전체 구조와 핵심 파일 연결을 먼저 분석
- 2. 실험 복제본에서 실제 수정과 검증을 수행
- 3. 검증을 통과한 개선 결과물만 승인 대기 대상으로 남김
- 4. 원본 폴더는 승인 전까지 절대 직접 수정하지 않음
- 최종 응답에는 진단 요약, 실험 결과, 검증 결과, 승인 대기용 핵심 변경점을 모두 포함
- 승인 전 단계에서는 원본 폴더를 직접 수정했다고 주장하지 말 것

[선택 주문]
- 주문 템플릿: 디버깅 기반 결함 교정 루프
- 실행 범위: 지정 범위만 구현
- 사용자 주문: final approve live validation after approval-gate narrowing fixes
- 위 주문은 현재 self-run 목적보다 우선순위를 침범하지 않는 범위에서 반영할 것

[디버깅 시스템 표준 프로토콜]
- 1단계 결함 식별 및 제거: validation_findings, runtime diagnostics, 보안 위반을 근거로 실제 결함만 식별하고 즉시 제거할 것
- 2단계 시스템 이해도 향상: 결함이 연결된 라우터, 상태, 저장 경로, 호출 체인을 설명 가능한 수준으로 재구성할 것
- 3단계 리스크 관리: 수정 파급 범위, 잠재 회귀, 미검증 영역, 승인 전 위험을 분리 기록할 것
- 4단계 성능 최적화: 결함 제거 후 남는 병목과 자원 낭비만 최적화하고, 기능 회귀를 만들지 말 것

[교정 조치 명령]
final approve live validation after approval-gate narrowing fixes

[대상 구조 요약]
- 디렉터리 수: 351
- 파일 수: 1685
- 텍스트/코드 파일 수: 982
- 분석 컨텍스트 포함 파일 수: 54
- 분석 컨텍스트 문자 수: 175491

[스킵 디렉터리]
- .git
- .playwright-mcp
- .pytest_cache
- .runtime
- .tmp
- .venv
- .venv-arcface310
- .venv.py313
- .venv.py313.20260409_200600.4823f7
- .venv.py313.20260409_201228.6ea186
- .venv.py313.20260418_205442.0184f1
- .venv.py313.cpu-2.10.0.20260418_210038
- .venv.py313.cpu-latest.20260418_205950
- .venv.py313.pypi-2.10.0.20260418_210125
- .venv.torchcheck313
- .venv312
- .venv313
- .vs
- __pycache__
- backend/__pycache__

[구조 프리뷰]
codeAI/
  .git/ [skip]
  .github/
    copilot-instructions.md
  .playwright-mcp/ [skip]
  .pytest_cache/ [skip]
  .runtime/ [skip]
  .tmp/ [skip]
  .venv/ [skip]
  .venv-arcface310/ [skip]
  .venv.py313/ [skip]
  .venv.py313.20260409_200600.4823f7/ [skip]
  .venv.py313.20260409_201228.6ea186/ [skip]
  .venv.py313.20260418_205442.0184f1/ [skip]
  .venv.py313.cpu-2.10.0.20260418_210038/ [skip]
  .venv.py313.cpu-latest.20260418_205950/ [skip]
  .venv.py313.pypi-2.10.0.20260418_210125/ [skip]
  .venv.torchcheck313/ [skip]
  .venv312/ [skip]
  .venv313/ [skip]
  .vs/ [skip]
  __pycache__/ [skip]
  AGENTS.md/
  backend/
    __pycache__/ [skip]
    admin/
      orchestrator/
        __pycache__/ [skip]
        debug_validation_jobs.py
        focused_self_healing_service.py
        path_utils.py
        project_root_service.py
        runtime_verification_service.py
        self_run_approval_service.py
        self_run_preparation_service.py
        self_run_record_service.py
        workspace_text_service.py
    api/
      __pycache__/ [skip]
      admin/
        __pycache__/ [skip]
        __init__.py
        routes.py
        schemas.py
      __init__.py
      router.py
    app/
      connectors/
        base.py
        payment_gateway.py
        shopify.py
      external_adapters/
        status_client.py
    application/
      __pycache__/ [skip]
      admin/
        __pycache__/ [skip]
        __init__.py
        runtime_verification_service.py
      __init__.py
    core/
      __init__.py
      auth.py
      database.py
      flow_registry.py
      models.py
      ops_logging.py
      runtime.py
      security.py
    data/
      provider.py
    generation_dsl/
      __pycache__/ [skip]
      __init__.py
      models.py
      normalizer.py
      parser.py
    generation_optimizer/
      __pycache__/ [skip]
      __init__.py
...[중략: 구조 프리뷰가 길어 일부만 포함]

[핵심 텍스트 파일]
- .github/copilot-instructions.md (11698 bytes)
- backend/admin/orchestrator/debug_validation_jobs.py (17498 bytes)
- backend/admin/orchestrator/focused_self_healing_service.py (8278 bytes)
- backend/admin/orchestrator/path_utils.py (2627 bytes)
- backend/admin/orchestrator/project_root_service.py (1701 bytes)
- backend/admin/orchestrator/runtime_verification_service.py (23790 bytes)
- backend/admin/orchestrator/self_run_approval_service.py (14798 bytes)
- backend/admin/orchestrator/self_run_preparation_service.py (5776 bytes)
- backend/admin/orchestrator/self_run_record_service.py (16267 bytes)
- backend/admin/orchestrator/workspace_text_service.py (7628 bytes)
- backend/api/admin/__init__.py (69 bytes)
- backend/api/admin/routes.py (1534 bytes)
- backend/api/admin/schemas.py (885 bytes)
- backend/api/__init__.py (0 bytes)
- backend/api/router.py (1498 bytes)
- backend/app/connectors/base.py (815 bytes)
- backend/app/connectors/payment_gateway.py (1366 bytes)
- backend/app/connectors/shopify.py (972 bytes)
- backend/app/external_adapters/status_client.py (2670 bytes)
- backend/application/admin/__init__.py (169 bytes)
- ...[중략: 핵심 텍스트 파일 목록이 길어 일부만 포함]

[분석용 파일 본문 컨텍스트 요약]
- 포함 파일 수: 54
- 누락 파일 수: 1
- 원본 컨텍스트 문자 수: 175491
- 컨텍스트 포함 파일에는 실행에 필요한 최소한의 소스 코드만 담길 것
- 주문 의도에 따라 실제 파일 본문 수정은 오케스트레이터 내부 코드 컨텍스트 조회로 보완할 것

[실행용 작업문 제약]
- 실행용 작업문에는 구조/컨텍스트를 요약본만 유지할 것
- 긴 산출물 파일명에 task 전문을 재사용하지 말 것
- 출고 아카이브 파일명은 output_dir 이름 또는 짧은 project_name 기준으로 생성할 것
- mode: full
- total_files: 147

## Files

- `README.md`
- `requirements.txt`
- `pyproject.toml`
- `Dockerfile`
- `Makefile`
- `app/main.py`
- `app/routes.py`
- `app/services/__init__.py`
- `app/services/runtime_service.py`
- `app/runtime.py`
- `app/diagnostics.py`
- `app/order_profile.py`
- `backend/main.py`
- `backend/core/runtime.py`
- `backend/core/flow_registry.py`
- `backend/api/router.py`
- `backend/data/provider.py`
- `backend/service/application_service.py`
- `frontend/app/page.tsx`
- `frontend/components/order-summary.tsx`
- `frontend/components/runtime-shell.tsx`
- `frontend/lib/api-client.ts`
- `configs/app.env.example`
- `configs/logging.yml`
- `scripts/dev.sh`
- `scripts/check.sh`
- `infra/README.md`
- `infra/docker-compose.override.yml`
- `docs/architecture.md`
- `docs/order_profile.md`
- `docs/flow_map.md`
- `docs/flow_registry.json`
- `docs/usage.md`
- `docs/runtime.md`
- `docs/deployment.md`
- `docs/testing.md`
- `docs/scaffold_inventory.md`
- `docs/stage_progress.md`
- `docs/stage_progress.json`
- `tests/conftest.py`
- `tests/test_health.py`
- `tests/test_routes.py`
- `tests/test_runtime.py`
- `app/auth_routes.py`
- `app/ops_routes.py`
- `backend/core/auth.py`
- `backend/core/security.py`
- `tests/test_security_runtime.py`
- `docs/runbook.md`
- `infra/prometheus.yml`
- `infra/deploy/security.md`
- `backend/app/external_adapters/status_client.py`
- `backend/app/connectors/base.py`
- `ai/adapters.py`
- `ai/schemas.py`
- `ai/router.py`
- `backend/service/strategy_service.py`
- `backend/service/domain_adapter_service.py`
- `backend/core/__init__.py`
- `backend/core/database.py`
- `backend/core/models.py`
- `backend/core/ops_logging.py`
- `tests/test_ai_pipeline.py`
- `.gitignore`
- `requirements.delivery.lock.txt`
- `app/__init__.py`
- `backend/app/connectors/shopify.py`
- `docs/ai_capability_plan.md`
- `ai/__init__.py`
- `ai/features.py`
- `ai/train.py`
- `ai/inference.py`
- `ai/evaluation.py`
- `ai/model_registry.py`
- `app/api/routes/__init__.py`
- `app/api/routes/health.py`
- `.env.example`
- `app/agents/__init__.py`
- `app/agents/orchestrator_roles.py`
- `app/api/__init__.py`
- `app/core/__init__.py`
- `app/core/config.py`
- `app/core/security.py`
- `app/external_adapters/__init__.py`
- `app/external_adapters/status_client.py`
- `tests/__init__.py`
- `docs/file_manifest.md`
- `docs/orchestrator_checklist.md`
- `docs/output_audit.json`
- `docs/orchestrator_artifacts.json`
- `docs/traceability_map.json`
- `docs/multi_role_contract.json`
- `docs/operational_readiness.md`
- `docs/generation-plan.json`
- `.codeai-template.json`
- `docs/auto_link_map.json`
- `docs/architecture.contract.json`
- `docs/role_separation.md`
- `docs/id_registry.json`
- `docs/product_identity.json`
- `docs/generator_checklist.md`
- `addons/nextjs_react/README.md`
- `addons/nextjs_react/.gitignore`
- `addons/nextjs_react/package.json`
- `addons/nextjs_react/tsconfig.json`
- `addons/nextjs_react/next-env.d.ts`
- `addons/nextjs_react/next.config.js`
- `addons/nextjs_react/app/layout.tsx`
- `addons/nextjs_react/app/loading.tsx`
- `addons/nextjs_react/app/page.tsx`
- `addons/nextjs_react/app/dashboard/page.tsx`
- `addons/nextjs_react/app/api/health/route.ts`
- `addons/nextjs_react/app/api/brief/route.ts`
- `addons/nextjs_react/app/globals.css`
- `addons/nextjs_react/components/dashboardclient.tsx`
- `addons/nextjs_react/components/heropanel.tsx`
- `addons/nextjs_react/components/metriccluster.tsx`
- `addons/nextjs_react/components/signalmatrix.tsx`
- `addons/nextjs_react/components/focusrail.tsx`
- `addons/nextjs_react/components/insighttimeline.tsx`
- `addons/nextjs_react/components/executionboard.tsx`
- `addons/nextjs_react/components/themetoggle.tsx`
- `addons/nextjs_react/lib/types.ts`
- `addons/nextjs_react/lib/data.ts`
- `addons/node_service/README.md`
- `addons/node_service/package.json`
- `addons/node_service/tsconfig.json`
- `addons/node_service/src/types.ts`
- `addons/node_service/src/config.ts`
- `addons/node_service/src/lib/runtimeStore.ts`
- `addons/node_service/src/repositories/orderRepository.ts`
- `addons/node_service/src/services/orderService.ts`
- `addons/node_service/src/http/handlers/health.go`
- `addons/node_service/src/http/handlers/inventory.go`
- `addons/node_service/src/http/router.go`
- `addons/go_service/README.md`
- `addons/go_service/go.mod`
- `addons/go_service/cmd/app/main.go`
- `addons/go_service/internal/app/app.go`
- `addons/go_service/internal/http/router.go`
- `addons/go_service/internal/http/handlers/health.go`
- `addons/go_service/internal/http/handlers/inventory.go`
- `addons/go_service/internal/service/inventory_service.go`
- `addons/go_service/internal/repository/inventory_repository.go`
- `addons/go_service/internal/platform/runtime_store.go`
- `addons/go_service/internal/domain/inventory.go`
- `docs/multi_generator_matrix.json`
