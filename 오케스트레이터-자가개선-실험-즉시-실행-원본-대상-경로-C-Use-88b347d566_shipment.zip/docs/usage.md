# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 사용 가이드

1. `pip install -r requirements.txt`
2. `uvicorn app.main:create_application --factory --host 0.0.0.0 --port 8000`
3. `/health`, `/runtime`, `/report` 확인
