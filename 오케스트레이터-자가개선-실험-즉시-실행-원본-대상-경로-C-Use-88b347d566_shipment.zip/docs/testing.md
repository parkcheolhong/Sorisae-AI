# testing

- `python -m compileall app backend tests ai`
- `pytest -q -s tests/test_health.py tests/test_routes.py tests/test_runtime.py tests/test_security_runtime.py`
- 필요 시 출고 ZIP 재현 검증 확인
