# deployment

- `docker build -t customer-order-generator .`
- `docker run --rm -p 8000:8000 --env-file configs/app.env.example customer-order-generator`
- 부팅 후 `/health`, `/runtime`, `/report` 확인으로 container run 검증
