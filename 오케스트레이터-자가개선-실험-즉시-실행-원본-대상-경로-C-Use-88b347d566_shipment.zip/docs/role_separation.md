# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 role separation

- document_id: GEN-DSL-001
- project_id: GEN-PROJECT-001
- profile: python_fastapi

## Auto-linked roles

- GRAPH-NODE-001 / api-entrypoint / app/main.py / TPL-PYTHON_FASTAPI-001
- GRAPH-NODE-002 / health-route / app/api/routes/health.py / TPL-PYTHON_FASTAPI-002
- GRAPH-NODE-003 / service-package-export / app/services/__init__.py / TPL-PYTHON_FASTAPI-003
- GRAPH-NODE-004 / runtime-service / app/services/runtime_service.py / TPL-PYTHON_FASTAPI-004
- GRAPH-NODE-005 / runtime-config / app/core/config.py / TPL-PYTHON_FASTAPI-005
- GRAPH-NODE-006 / security-guard / app/core/security.py / TPL-PYTHON_FASTAPI-006
- GRAPH-NODE-007 / upstream-status-adapter / app/external_adapters/status_client.py / TPL-PYTHON_FASTAPI-007
- GRAPH-NODE-008 / multi-role-orchestrator / app/agents/orchestrator_roles.py / TPL-PYTHON_FASTAPI-008
- GRAPH-NODE-009 / health-test / tests/test_health.py / TPL-PYTHON_FASTAPI-009
- GRAPH-NODE-010 / file-manifest / docs/file_manifest.md / TPL-PYTHON_FASTAPI-010
- GRAPH-NODE-011 / orchestrator-checklist / docs/orchestrator_checklist.md / TPL-PYTHON_FASTAPI-011
- GRAPH-NODE-012 / output-audit / docs/output_audit.json / TPL-PYTHON_FASTAPI-012
- GRAPH-NODE-013 / artifact-ledger / docs/orchestrator_artifacts.json / TPL-PYTHON_FASTAPI-013
- GRAPH-NODE-014 / traceability-map / docs/traceability_map.json / TPL-PYTHON_FASTAPI-014
- GRAPH-NODE-015 / auto-link-map / docs/auto_link_map.json / TPL-PYTHON_FASTAPI-015
- GRAPH-NODE-016 / architecture-contract / docs/architecture.contract.json / TPL-PYTHON_FASTAPI-016
- GRAPH-NODE-017 / role-separation / docs/role_separation.md / TPL-PYTHON_FASTAPI-017
- GRAPH-NODE-018 / generator-checklist / docs/generator_checklist.md / TPL-PYTHON_FASTAPI-018
- GRAPH-NODE-019 / multi-role-contract / docs/multi_role_contract.json / TPL-PYTHON_FASTAPI-019
- GRAPH-NODE-020 / operational-readiness / docs/operational_readiness.md / TPL-PYTHON_FASTAPI-020
- GRAPH-NODE-021 / template-contract / .codeai-template.json / TPL-PYTHON_FASTAPI-021

## Template bindings

- BIND-001 => GRAPH-NODE-001 => app/main.py
- BIND-002 => GRAPH-NODE-002 => app/api/routes/health.py
- BIND-003 => GRAPH-NODE-003 => app/services/__init__.py
- BIND-004 => GRAPH-NODE-004 => app/services/runtime_service.py
- BIND-005 => GRAPH-NODE-005 => app/core/config.py
- BIND-006 => GRAPH-NODE-006 => app/core/security.py
- BIND-007 => GRAPH-NODE-007 => app/external_adapters/status_client.py
- BIND-008 => GRAPH-NODE-008 => app/agents/orchestrator_roles.py
- BIND-009 => GRAPH-NODE-009 => tests/test_health.py
- BIND-010 => GRAPH-NODE-010 => docs/file_manifest.md
- BIND-011 => GRAPH-NODE-011 => docs/orchestrator_checklist.md
- BIND-012 => GRAPH-NODE-012 => docs/output_audit.json
- BIND-013 => GRAPH-NODE-013 => docs/orchestrator_artifacts.json
- BIND-014 => GRAPH-NODE-014 => docs/traceability_map.json
- BIND-015 => GRAPH-NODE-015 => docs/auto_link_map.json
- BIND-016 => GRAPH-NODE-016 => docs/architecture.contract.json
- BIND-017 => GRAPH-NODE-017 => docs/role_separation.md
- BIND-018 => GRAPH-NODE-018 => docs/generator_checklist.md
- BIND-019 => GRAPH-NODE-019 => docs/multi_role_contract.json
- BIND-020 => GRAPH-NODE-020 => docs/operational_readiness.md
- BIND-021 => GRAPH-NODE-021 => .codeai-template.json

## Quality gates

- required-files-present
- service-package-contract
- multi-role-contract-generated
- auto-link-map-generated
- architecture-contract-generated
- role-separation-generated
- generator-checklist-generated
- output-audit-generated
- traceability-generated
- self-configurable-settings
- syntax-verifiable
