# runtime

profile: 업무 자동화/에이전트 서비스
requested_stack: FastAPI, queue-runtime, ops-panel, ai-engine, training-pipeline, model-registry

- health: `/health`
- runtime: `/runtime`
- report: `/report`
- ops status: `/ops/status`
