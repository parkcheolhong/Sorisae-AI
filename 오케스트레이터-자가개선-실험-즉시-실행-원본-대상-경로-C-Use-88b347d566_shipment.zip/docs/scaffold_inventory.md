# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 scaffold inventory

6단계 중 어느 단계를 실행해도 아래 골조는 항상 유지되어야 합니다.

- backend/main.py
- backend/core/runtime.py
- backend/data/provider.py
- backend/service/application_service.py
- backend/api/router.py
- frontend/app/page.tsx
- docs/order_profile.md
