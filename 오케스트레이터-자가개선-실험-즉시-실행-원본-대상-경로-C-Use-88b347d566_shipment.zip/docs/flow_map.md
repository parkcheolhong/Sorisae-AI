# 오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566 flow map

주문 기반 자율 생성기의 공통 흐름입니다.

- FLOW-001 / FLOW-001-1 / INTAKE / step=1 / trace=FLOW-001:FLOW-001-1:INTAKE - 주문 해석
- FLOW-001 / FLOW-001-2 / STRUCTURE / step=2 / trace=FLOW-001:FLOW-001-2:STRUCTURE - 기능 구조화
- FLOW-002 / FLOW-002-1 / SERVICE_BIND / step=1 / trace=FLOW-002:FLOW-002-1:SERVICE_BIND - 서비스 연결
- FLOW-003 / FLOW-003-1 / DELIVERY / step=1 / trace=FLOW-003:FLOW-003-1:DELIVERY - 산출물 패키징
