# FILE-ID: FILE-BACKEND-MAIN-PY
# SECTION-ID: SECTION-BACKEND-MAIN-PY-MAIN
# FEATURE-ID: FEATURE-BACKEND-MAIN-PY-RUNTIME
# CHUNK-ID: CHUNK-BACKEND-MAIN-PY-001

from app.main import app, create_application

__all__ = ['app', 'create_application']

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('app.main:create_application', factory=True, host='0.0.0.0', port=8000, reload=False)
