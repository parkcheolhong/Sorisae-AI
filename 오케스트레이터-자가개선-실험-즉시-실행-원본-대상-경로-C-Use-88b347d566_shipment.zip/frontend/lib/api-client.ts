/* FILE-ID: FILE-FRONTEND-LIB-API-CLIENT-TS */
/* SECTION-ID: SECTION-FRONTEND-LIB-API-CLIENT-TS-MAIN */
/* FEATURE-ID: FEATURE-FRONTEND-LIB-API-CLIENT-TS-RUNTIME */
/* CHUNK-ID: CHUNK-FRONTEND-LIB-API-CLIENT-TS-001 */

export async function fetchRuntime(baseUrl: string) {
  const response = await fetch(`${baseUrl}/runtime`, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error('runtime fetch failed');
  }
  return response.json();
}

export async function fetchOrderProfile(baseUrl: string) {
  const response = await fetch(`${baseUrl}/order-profile`, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error('order profile fetch failed');
  }
  return response.json();
}

export async function fetchOpsStatus(baseUrl: string) {
  const response = await fetch(`${baseUrl}/ops/status`, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error('ops status fetch failed');
  }
  return response.json();
}

export async function fetchAuthSettings(baseUrl: string) {
  const response = await fetch(`${baseUrl}/auth/settings`, { cache: 'no-store' });
  if (!response.ok) {
    throw new Error('auth settings fetch failed');
  }
  return response.json();
}
