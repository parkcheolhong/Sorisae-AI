/* FILE-ID: FILE-FRONTEND-COMPONENTS-RUNTIME-SHELL-TSX */
/* SECTION-ID: SECTION-FRONTEND-COMPONENTS-RUNTIME-SHELL-TSX-MAIN */
/* FEATURE-ID: FEATURE-FRONTEND-COMPONENTS-RUNTIME-SHELL-TSX-RUNTIME */
/* CHUNK-ID: CHUNK-FRONTEND-COMPONENTS-RUNTIME-SHELL-TSX-001 */

type Props = {
  title: string;
  summary: string;
};

export function RuntimeShell({ title, summary }: Props) {
  return (
    <section style={{ border: '1px solid #d0d7de', borderRadius: 12, padding: 16, background: '#f8fafc' }}>
      <h1>{title}</h1>
      <p>{summary}</p>
      <p>runtime / diagnostics / ops status / shipment readiness 를 한 번에 검토합니다.</p>
    </section>
  );
}
