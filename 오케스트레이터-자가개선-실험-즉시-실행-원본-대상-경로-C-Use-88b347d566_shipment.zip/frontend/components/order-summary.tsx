/* FILE-ID: FILE-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX */
/* SECTION-ID: SECTION-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-MAIN */
/* FEATURE-ID: FEATURE-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-RUNTIME */
/* CHUNK-ID: CHUNK-FRONTEND-COMPONENTS-ORDER-SUMMARY-TSX-001 */

type Props = {
  title: string;
  items: string[];
};

export function OrderSummary({ title, items }: Props) {
  return (
    <section style={{ border: '1px solid #d0d7de', borderRadius: 12, padding: 16 }}>
      <h2>{title}</h2>
      <p>구매자 요청과 운영 결과를 같은 화면에서 점검합니다.</p>
      <ul>{items.map((item) => <li key={item}>{item}</li>)}</ul>
    </section>
  );
}
