# FILE-ID: FILE-APP-MAIN-PY
# SECTION-ID: SECTION-APP-MAIN-PY-MAIN
# FEATURE-ID: FEATURE-APP-MAIN-PY-RUNTIME
# CHUNK-ID: CHUNK-APP-MAIN-PY-001

from fastapi import FastAPI
from app.auth_routes import auth_router
from app.ops_routes import ops_router
from app.routes import router
from app.services import build_runtime_payload, summarize_health
from app.diagnostics import build_diagnostic_report
from app.order_profile import get_order_profile
from ai.router import router as ai_router

def create_application() -> FastAPI:
    app = FastAPI(title='오케스트레이터-자가개선-실험-즉시-실행-원본-대상-경로-C-Use-88b347d566', version='0.1.0')
    app.include_router(router)
    app.include_router(auth_router)
    app.include_router(ops_router)
    app.include_router(ai_router)

    @app.get('/')
    def root():
        profile = get_order_profile()
        return {
            'status': 'ok',
            'project': profile['project_name'],
            'profile': profile['label'],
            'mode': 'customer-order-generator',
        }

    @app.get('/runtime')
    def runtime():
        payload = build_runtime_payload(runtime_mode='runtime')
        payload['health'] = summarize_health()
        payload['diagnostics'] = build_diagnostic_report()
        return payload

    return app

app = create_application()
