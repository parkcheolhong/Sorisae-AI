# FILE-ID: FILE-SCRIPTS-CHECK-SH
# SECTION-ID: SECTION-SCRIPTS-CHECK-SH-MAIN
# FEATURE-ID: FEATURE-SCRIPTS-CHECK-SH-RUNTIME
# CHUNK-ID: CHUNK-SCRIPTS-CHECK-SH-001

#!/usr/bin/env bash
set -euo pipefail

test -f requirements.delivery.lock.txt
python -m compileall app backend tests ai
pytest -q -s tests/test_health.py tests/test_routes.py tests/test_runtime.py tests/test_security_runtime.py
