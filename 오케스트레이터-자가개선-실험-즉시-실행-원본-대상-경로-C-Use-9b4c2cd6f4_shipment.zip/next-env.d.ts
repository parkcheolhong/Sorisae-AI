/* FILE-ID: FILE-NEXT-ENV-D-TS */
/* SECTION-ID: SECTION-NEXT-ENV-D-TS-MAIN */
/* FEATURE-ID: FEATURE-NEXT-ENV-D-TS-RUNTIME */
/* CHUNK-ID: CHUNK-NEXT-ENV-D-TS-001 */

/// <reference types='next' />
/// <reference types='next/image-types/global' />
