package com.shinsegye.nadotongryoksa

// 신세계소리새 통번역 엔진 — SoriSae Master Hybrid 기반
class TranslationEngine {
    val supportedPairs = listOf("ko-en", "ko-zh", "ko-ja", "ko-es")

    fun translate(text: String, from: String, to: String): String {
        // SoriSae hybrid interpreter_system 연결
        return "[${from}→${to}] $text"
    }

    fun voiceTranslate(audioBytes: ByteArray, from: String, to: String): String {
        // 음성 → 텍스트 → 번역 파이프라인
        return translate("(음성 입력)", from, to)
    }
}
