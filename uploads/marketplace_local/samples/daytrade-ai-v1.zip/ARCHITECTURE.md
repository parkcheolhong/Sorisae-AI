# 모듈 맵

- daytrade/feed/        : MarketFeed + 합성/CSV 리플레이 + Binance/Upbit/Alpaca 라이브
- daytrade/features/    : OBI · OBI z-score · 거래량 급증 · 마이크로 모멘텀 · VWAP · 스프레드
- daytrade/detection/   : 규칙 기반 시그널 + confidence
- daytrade/inference/   : 플러거블 모델(휴리스틱 기본 / ONNX 어댑터)
- daytrade/risk/        : 포지션·총노출·레버리지 한도 + 서킷브레이커 + 슬리피지 가드
- daytrade/execution/   : OrderExecutor + PaperExecutor + OrderRouter(예외 흡수) + Portfolio
- daytrade/training/    : 라벨링·데이터셋 · 워크포워드 OOS 검증 · Optuna 튜닝 · ONNX export
- daytrade/rl/          : TradingEnv + PPO/연속 PPO/REINFORCE
- daytrade/ops/         : MLOps 재학습·핫스왑·자동 롤백·롤백 가드·스케줄러
- daytrade/storage/     : 고속 바이너리 틱 스토어(.dts) + 일별 캡처 레코더
- daytrade/testing/     : 인프로세스 장애 주입(FaultInjectingFeed/FlakyExecutor)
- daytrade/pipeline.py  : 전 구간 결선(틱당 처리)
- daytrade/monitoring/  : 레이턴시/슬리피지/P&L/Sharpe/MDD + Prometheus 메트릭
- daytrade/backtest/    : 시뮬레이션 러너 + 리포트 고도화 + Backtrader 어댑터
- cpp/                  : C++ 저지연 코어(Python과 1e-9 골든 패리티)
- daytrade/cli.py       : sim / replay / walkforward / tune / train / rl / events 진입점
