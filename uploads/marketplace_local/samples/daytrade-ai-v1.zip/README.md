# daytrade-ai — AI 주식 단타(스캘핑) 자동매매 시스템 [실험 빌드 v0.9]

오더북/체결 흐름을 실시간 분석해 밀리초 단위로 시그널을 만들고 자동 주문하는
Python 자동매매 파이프라인입니다. 기본은 모의투자(paper)·백테스트이며,
실거래는 코드 레벨 이중 안전 게이트를 통과해야만 활성화됩니다.

## 빠른 시작
```bash
pip install -r requirements.txt
python -m daytrade.cli sim --symbol AAPL --ticks 5000 --obi-threshold 5e5 --event-prob 0.05
python -m daytrade.cli sim --ticks 5000 --report-html report.html   # 분석 리포트
python -m pytest -q   # 286 passed
```

## 아키텍처
feed → FeatureEngine → DetectionEngine → AI Inference → RiskManager → OrderRouter → Portfolio
(+ Monitoring: 레이턴시 p50/p95/p99 · 슬리피지 · P&L · Sharpe · MDD)

## 포함 범위
- 강화학습(PPO/연속 포지션) · 워크포워드 OOS 검증 · Optuna 튜닝
- MLOps 자동 재학습·핫스왑·자동 롤백·롤백 쿨다운/블랙리스트·스케줄러
- 고속 바이너리 틱 스토어(.dts) · 실데이터 일별 캡처 · Backtrader 어댑터
- C++ 저지연 코어(Python과 1e-9 수치 동일성) · 백테스트 HTML 리포트

전체 소스는 저장소 `apps/daytrade-ai/` 에 포함되어 있습니다.
GitHub: https://github.com/parkcheolhong/codeAI/tree/main/apps/daytrade-ai
