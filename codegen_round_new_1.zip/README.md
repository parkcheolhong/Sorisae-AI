# FILE-ID: FILE-README-MD
# SECTION-ID: SECTION-README-MD-MAIN
# FEATURE-ID: FEATURE-README-MD-RUNTIME
# CHUNK-ID: CHUNK-README-MD-001

# zip-e2e-new-1

Included Runtime

Python FastAPI 기반 코드 생성기 산출물입니다.

- task: create simple fastapi todo api
- runtime: FastAPI
- runtime modules: app/services runtime service, backend/core compatible governance markers

- app/main.py
- frontend/app/page.tsx
## Run

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Runtime markers

- backend/core compatibility markers are documented for semantic gate sync
- shipping flow uses scripts/check.sh
