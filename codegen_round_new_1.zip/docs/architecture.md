# zip-e2e-new-1 architecture

- app/main.py: FastAPI entrypoint
- app/api/routes/health.py: health route
- app/core/security.py: security baseline
- app/services/runtime_service.py: runtime summary service
- app/external_adapters/status_client.py: status adapter
